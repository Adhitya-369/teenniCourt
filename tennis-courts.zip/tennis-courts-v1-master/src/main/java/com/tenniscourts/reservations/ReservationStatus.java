package com.tenniscourts.reservations;

public enum ReservationStatus {
  READY_TO_PLAY,
  CANCELLED,
  RESCHEDULED
}
